/*
 * Copyright 2019 Broadcom. The term "Broadcom" refers to Broadcom Inc. and/or
 * its subsidiaries.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file stpd_main.cpp
 * @author your name (you@domain.com)
 * @brief Главный файл, содержащий точку входа для демона STP. Выполняет общую инициализацию и запускает основные модули.
 * Основные задачи:
 * Настройка окружения (сигналы, логирование).
 * Запуск потока обработки пакетов BPDU.
 * Управление жизненным циклом демона.
 * @version 0.1
 * @date 2024-11-30
 *
 * @copyright Copyright (c) 2024
 *
 */

#include <iostream>

extern "C" void stpd_main();

/**
 * @brief Основная функция, запускающая демон. принимает аргументы командной строки, инициализирует логирование и вызывает вспомогательные функции.
 *
 * @param argc
 * @param argv
 * @return int
 */
int main(int argc, char **argv)
{
    stpd_main();
    return 0;
}
